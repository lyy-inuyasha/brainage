CUDA_VISIBLE_DEVICES=3 python test_soft.py --ckpt logs/sfcn-gm_lr0.0001_bs8/20230516190207/20230517092430-e110-2.9050.ckpt
